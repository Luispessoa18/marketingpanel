import io
import json
import time
import zipfile
import datetime
import requests
from typing import Optional
from camoufox.sync_api import Camoufox
from session import save_session, load_session

INSTAGRAM_URL = "https://www.instagram.com"


class InstagramClient:
    def __init__(self, headless: bool | str = "virtual"):
        self._headless = headless
        self._camoufox: Optional[Camoufox] = None
        self._browser = None
        self._page = None

    # ── context manager ──────────────────────────────────────────────────────

    def __enter__(self):
        self._camoufox = Camoufox(headless=self._headless)
        self._browser = self._camoufox.__enter__()
        self._page = self._browser.new_page()
        return self

    def __exit__(self, *args):
        self._camoufox.__exit__(*args)

    # ── internal helpers ─────────────────────────────────────────────────────

    def _goto(self, url: str, wait: str = "domcontentloaded") -> None:
        self._page.goto(url, wait_until=wait)
        self._dismiss_cookie_banner()

    def _dismiss_cookie_banner(self) -> None:
        try:
            btn = self._page.locator("text=Allow all cookies").first
            if btn.is_visible(timeout=2000):
                btn.click()
        except Exception:
            pass

    def _wait_for_selector(self, selector: str, timeout: int = 10_000):
        return self._page.wait_for_selector(selector, timeout=timeout)

    def _is_logged_in(self) -> bool:
        self._page.goto(INSTAGRAM_URL, wait_until="domcontentloaded")
        time.sleep(2)
        return "login" not in self._page.url

    # ── auth ─────────────────────────────────────────────────────────────────

    def login(self, username: str, password: str, save: bool = True) -> bool:
        """Faz login no Instagram. Retorna True se bem-sucedido."""
        # Tenta carregar sessão salva primeiro
        self._goto(INSTAGRAM_URL)
        if load_session(self._page, username):
            try:
                self._page.reload(wait_until="domcontentloaded", timeout=60_000)
            except Exception:
                pass  # cookies já foram aplicados; continua mesmo se reload travar
            time.sleep(2)
            if self._is_logged_in():
                print("[login] Sessão restaurada com sucesso.")
                return True
            print("[login] Sessão expirada, fazendo login manual...")

        # Login manual — /accounts/login/ trava; usamos a homepage e clicamos
        # no botão "Entrar" caso o formulário não apareça inline (mobile view).
        self._page.set_viewport_size({"width": 1280, "height": 800})
        self._goto(f"{INSTAGRAM_URL}/")

        USER_SEL = (
            "input[name='username'], "
            "input[autocomplete='username'], "
            "input[placeholder*='username' i], "
            "input[placeholder*='Mobile' i], "
            "input[placeholder*='Número' i], "
            "input[aria-label*='username' i], "
            "input[aria-label*='Mobile' i]"
        )
        PASS_SEL = "input[name='password'], input[type='password']"

        # Se o formulário não estiver inline, clica em "Entrar" / "Log in"
        try:
            self._page.wait_for_selector(USER_SEL, timeout=5_000)
        except Exception:
            LOGIN_BTN = "a[href*='/accounts/login'], button:has-text('Entrar'), button:has-text('Log in'), a:has-text('Entrar'), a:has-text('Log in')"
            try:
                self._page.locator(LOGIN_BTN).first.click()
                self._page.wait_for_selector(USER_SEL, timeout=20_000)
            except Exception:
                self._page.screenshot(path="login_debug.png")
                print("[login] Campo de usuário não encontrado. Screenshot salvo em login_debug.png")
                return False

        self._page.locator(USER_SEL).first.fill(username)
        self._page.locator(PASS_SEL).first.fill(password)
        self._page.locator(PASS_SEL).first.press("Enter")

        # Aguarda redirecionamento pós-login
        try:
            self._page.wait_for_url(
                lambda url: "login" not in url, timeout=15_000
            )
        except Exception:
            print("[login] Falha no login. Verifique usuário/senha ou 2FA.")
            return False

        time.sleep(3)

        # Descarta popups de notificação
        try:
            not_now = self._page.locator("text=Not Now").first
            if not_now.is_visible(timeout=3000):
                not_now.click()
        except Exception:
            pass

        if save:
            save_session(self._page, username)

        print("[login] Login realizado com sucesso.")
        return True

    # ── profile scraping ─────────────────────────────────────────────────────

    def inspect(self, target_username: str, out_dir: str = ".") -> None:
        """Salva screenshot + HTML da página do perfil para análise de seletores."""
        import os
        url = f"{INSTAGRAM_URL}/{target_username}/"
        print(f"[inspect] Navegando para {url}")
        self._goto(url)
        time.sleep(4)
        # Se redirecionou para login, registra isso também
        current = self._page.url
        print(f"[inspect] URL atual: {current}")
        img_path = os.path.join(out_dir, f"inspect_{target_username}.png")
        html_path = os.path.join(out_dir, f"inspect_{target_username}.html")
        self._page.screenshot(path=img_path, full_page=True)
        html = self._page.content()
        with open(html_path, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"[inspect] Screenshot → {img_path}")
        print(f"[inspect] HTML       → {html_path}")

    def get_profile(self, target_username: str) -> dict:
        """Extrai informações do perfil via API interna do Instagram."""
        profile_url = f"{INSTAGRAM_URL}/{target_username}/"
        api_url = f"{INSTAGRAM_URL}/api/v1/users/web_profile_info/?username={target_username}"

        # Navega para a página do perfil primeiro (garante cookies/sessão no contexto)
        self._page.set_viewport_size({"width": 1280, "height": 800})
        self._goto(profile_url)
        time.sleep(2)

        if "login" in self._page.url:
            print("[profile] Redirecionado para login — sessão inválida ou expirada.")
            return {"username": target_username, "url": profile_url, "error": "not_logged_in"}

        # Chama a API interna usando fetch() no contexto autenticado do browser
        raw = self._page.evaluate(
            """async (url) => {
                const r = await fetch(url, {
                    headers: {
                        "x-ig-app-id": "936619743392459",
                        "accept": "*/*"
                    },
                    credentials: "include"
                });
                if (!r.ok) return null;
                return await r.json();
            }""",
            api_url,
        )

        if not raw:
            print("[profile] API não retornou dados.")
            return {"username": target_username, "url": profile_url, "error": "api_failed"}

        u = raw.get("data", {}).get("user", {})

        data: dict = {
            "username": target_username,
            "url": profile_url,
            "full_name": u.get("full_name"),
            "bio": u.get("biography"),
            "external_link": u.get("external_url") or None,
            "avatar_url": u.get("profile_pic_url_hd") or u.get("profile_pic_url"),
            "verified": u.get("is_verified", False),
            "private": u.get("is_private", False),
            "posts": str(u.get("edge_owner_to_timeline_media", {}).get("count", "")),
            "followers": str(u.get("edge_followed_by", {}).get("count", "")),
            "following": str(u.get("edge_follow", {}).get("count", "")),
        }
        return data

    def scrape_profile(self, target_username: str, out_dir: str = ".") -> str:
        """
        Raspa o perfil: screenshot, avatar, até 6 posts fixados + 3 seguintes.
        Empacota tudo num ZIP e retorna o caminho do arquivo.
        """
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = f"{target_username}_{timestamp}"

        profile_url = f"{INSTAGRAM_URL}/{target_username}/"
        api_url = f"{INSTAGRAM_URL}/api/v1/users/web_profile_info/?username={target_username}"

        self._page.set_viewport_size({"width": 1280, "height": 800})
        self._goto(profile_url)
        time.sleep(3)

        if "login" in self._page.url:
            raise RuntimeError("Sessão inválida ou expirada.")

        # API interna
        raw = self._page.evaluate(
            """async (url) => {
                const r = await fetch(url, {
                    headers: {"x-ig-app-id": "936619743392459", "accept": "*/*"},
                    credentials: "include"
                });
                if (!r.ok) return null;
                return await r.json();
            }""",
            api_url,
        )
        if not raw:
            raise RuntimeError("API do Instagram não retornou dados.")

        u = raw.get("data", {}).get("user", {})

        # Screenshot da viewport (não full_page para ficar menor)
        screenshot_bytes = self._page.screenshot(full_page=False)

        # Seleciona posts: 6 fixados + 3 seguintes (ou primeiros 9 se sem is_pinned)
        edges = u.get("edge_owner_to_timeline_media", {}).get("edges", [])
        pinned = [e["node"] for e in edges if e["node"].get("is_pinned") is True]
        others = [e["node"] for e in edges if not e["node"].get("is_pinned")]
        if pinned:
            selected = pinned[:6] + others[:3]
        else:
            selected = [e["node"] for e in edges[:9]]

        # Sessão requests para baixar imagens (CDN não requer auth, mas passa UA)
        sess = requests.Session()
        sess.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Referer": "https://www.instagram.com/",
        })

        def _download(url: str) -> bytes | None:
            try:
                r = sess.get(url, timeout=15)
                r.raise_for_status()
                return r.content
            except Exception as e:
                print(f"[scrape] Aviso: falha ao baixar {url[:60]}… — {e}")
                return None

        # Avatar
        avatar_url = u.get("profile_pic_url_hd") or u.get("profile_pic_url")
        avatar_bytes = _download(avatar_url) if avatar_url else None

        # Imagens dos posts
        post_images: list[tuple[str, bytes]] = []
        for i, node in enumerate(selected, 1):
            img_url = node.get("display_url") or node.get("thumbnail_src")
            if node.get("__typename") == "GraphSidecar":
                children = node.get("edge_sidecar_to_children", {}).get("edges", [])
                if children:
                    img_url = children[0]["node"].get("display_url") or img_url
            if img_url:
                data = _download(img_url)
                if data:
                    label = "pinned" if node.get("is_pinned") else "post"
                    post_images.append((f"{label}_{i:02d}.jpg", data))

        # Profile JSON
        profile_data = {
            "username": target_username,
            "full_name": u.get("full_name"),
            "bio": u.get("biography"),
            "followers": u.get("edge_followed_by", {}).get("count"),
            "following": u.get("edge_follow", {}).get("count"),
            "posts_count": u.get("edge_owner_to_timeline_media", {}).get("count"),
            "verified": u.get("is_verified"),
            "private": u.get("is_private"),
            "external_url": u.get("external_url"),
            "avatar_url": avatar_url,
            "scraped_at": timestamp,
        }

        # Monta ZIP
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(
                f"{base_name}/profile.json",
                json.dumps(profile_data, indent=2, ensure_ascii=False),
            )
            zf.writestr(f"{base_name}/screenshot.png", screenshot_bytes)
            if avatar_bytes:
                zf.writestr(f"{base_name}/avatar.jpg", avatar_bytes)
            for fname, img_bytes in post_images:
                zf.writestr(f"{base_name}/posts/{fname}", img_bytes)

        zip_path = f"{out_dir}/{base_name}.zip"
        with open(zip_path, "wb") as f:
            f.write(zip_buffer.getvalue())

        print(f"[scrape] ZIP gerado: {zip_path}  ({len(post_images)} imagens de posts)")
        return zip_path

    def analyze_profile(self, target_username: str) -> dict:
        """Retorna dados do perfil + análise derivada."""
        profile = self.get_profile(target_username)
        analysis = self._derive_analysis(profile)
        return {"profile": profile, "analysis": analysis}

    @staticmethod
    def _derive_analysis(profile: dict) -> dict:
        analysis: dict = {}

        # Engajamento estimado (apenas com seguidores, sem dados de posts)
        followers_raw = profile.get("followers") or "0"
        followers_str = (
            followers_raw.replace(",", "").replace(".", "").replace(" ", "")
        )
        try:
            followers = int(followers_str)
        except ValueError:
            # handles "1.2M", "45K" etc
            followers = _parse_abbreviated(followers_raw)

        analysis["followers_int"] = followers

        if followers == 0:
            analysis["tier"] = "unknown"
        elif followers < 1_000:
            analysis["tier"] = "nano (< 1K)"
        elif followers < 10_000:
            analysis["tier"] = "micro (1K–10K)"
        elif followers < 100_000:
            analysis["tier"] = "mid-tier (10K–100K)"
        elif followers < 1_000_000:
            analysis["tier"] = "macro (100K–1M)"
        else:
            analysis["tier"] = "mega (> 1M)"

        # Bio keywords
        bio = profile.get("bio") or ""
        analysis["bio_length"] = len(bio)
        analysis["bio_has_emoji"] = any(
            ord(c) > 127 for c in bio
        )
        analysis["bio_has_link_mention"] = any(
            kw in bio.lower() for kw in ["http", "www", "link", "linktree"]
        )

        analysis["is_business_likely"] = (
            profile.get("external_link") is not None
            or analysis["bio_has_link_mention"]
        )
        analysis["is_verified"] = profile.get("verified", False)
        analysis["is_private"] = profile.get("private", False)

        return analysis


def _parse_abbreviated(value: str) -> int:
    value = value.strip().replace(",", ".").upper()
    try:
        if value.endswith("M"):
            return int(float(value[:-1]) * 1_000_000)
        if value.endswith("K"):
            return int(float(value[:-1]) * 1_000)
        return int(float(value))
    except Exception:
        return 0
