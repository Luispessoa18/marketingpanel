"""
Análise de ZIPs de perfis do Instagram via IA.

Configura via variáveis de ambiente:
  AI_PROVIDER   = claude | gemini | openai | openrouter  (padrão: claude)
  AI_MODEL      = nome do modelo (padrão varia por provider)
  ANTHROPIC_API_KEY
  GOOGLE_API_KEY
  OPENAI_API_KEY
  OPENROUTER_API_KEY
"""

import base64
import json
import os
import re
import zipfile


# ── JSON schema para relatório estruturado ────────────────────────────────────

REPORT_SCHEMA_PROMPT = """\
Você é um especialista em estratégia de Instagram e marketing digital.
Analise o perfil fornecido e retorne APENAS um JSON válido, sem markdown, sem ```json, sem texto adicional.

O JSON deve seguir EXATAMENTE este schema (adapte todos os dados ao perfil analisado):

{
  "header": {
    "username": "nome_usuario",
    "full_name": "Nome Completo",
    "subtitle": "Cargo/Empresa · Mês Ano",
    "stats": {
      "posts": "número",
      "followers": "ex: 13.5K",
      "following": "número",
      "engagement_rate": "ex: ~0.6%"
    }
  },
  "diagnosis": {
    "current_positioning": "Análise do posicionamento percebido nos primeiros 5 segundos.",
    "positioning_verdict": "Veredicto objetivo em 1-2 frases.",
    "content_pillars": [
      {"label": "Nome do Pilar", "pct": 35, "color_var": "purple"}
    ],
    "central_problem": "Problema central de conteúdo do perfil.",
    "formats": [
      {"format": "Nome", "presence": "~X%", "note": "Observação"}
    ],
    "tone": "Análise do tom de voz atual.",
    "visual": "Análise da identidade visual.",
    "audience_current": "Quem está sendo atraído hoje.",
    "audience_target": "Quem deveria ser o público ideal.",
    "audience_gap": "Gap entre público atual e ideal.",
    "critical_gaps": [
      {"title": "Título do Gap", "description": "Descrição detalhada."}
    ]
  },
  "icp": {
    "primary_title": "Nome do Perfil Primário",
    "primary_demographics": "Descrição demográfica.",
    "primary_psychographics": "Descrição psicográfica.",
    "secondary_title": "Nome do Perfil Secundário",
    "secondary_demographics": "Descrição demográfica.",
    "secondary_psychographics": "Descrição psicográfica.",
    "pains": ["Dor 1", "Dor 2", "Dor 3"],
    "desires": ["Desejo 1", "Desejo 2", "Desejo 3"],
    "objections": ["Objeção 1 → como tratar", "Objeção 2", "Objeção 3", "Objeção 4"],
    "consumption_channels": "Onde esse público consome conteúdo."
  },
  "strategy": {
    "new_positioning": "Novo posicionamento proposto com destaque para a frase principal.",
    "bio_versions": [
      {"title": "Versão 1 — Nome", "content": "Texto completo da bio com emojis e quebras de linha usando \\n"}
    ],
    "content_pillars": [
      {"name": "Nome do Pilar", "tag": "TAG", "pct": "30%", "objective": "Objetivo", "examples": "Ex 1, Ex 2, Ex 3"}
    ],
    "format_mix": [
      {"format": "Nome do formato", "qty": "número ou faixa", "when": "Quando publicar"}
    ],
    "weekly_calendar": [
      {
        "day_label": "Segunda — Reel",
        "title": "Título do conteúdo",
        "meta": "Formato: X | Pilar: Y",
        "hook": "Gancho: texto de abertura",
        "cta": "CTA: chamada para ação"
      }
    ],
    "viral_hooks": [
      "\"Texto do hook 1\" — Gatilho: tipo",
      "\"Texto do hook 2\" — Gatilho: tipo",
      "\"Texto do hook 3\" — Gatilho: tipo",
      "\"Texto do hook 4\" — Gatilho: tipo",
      "\"Texto do hook 5\" — Gatilho: tipo"
    ],
    "funnel_top": "Estratégia de topo (descoberta).",
    "funnel_middle": "Estratégia de meio (nutrição).",
    "funnel_bottom": "Estratégia de fundo (conversão).",
    "funnel_paths": [
      {"label": "Caminho A", "text": "Descrição do caminho"},
      {"label": "Caminho B", "text": "Descrição do caminho"},
      {"label": "Caminho C", "text": "Descrição do caminho"}
    ],
    "funnel_post_conversion": "Estratégia pós-conversão.",
    "kpis": [
      {"kpi": "Nome do KPI", "target": "Meta", "reason": "Por que esse KPI importa"}
    ]
  },
  "quick_wins": [
    {"title": "Título da ação", "description": "Descrição com tempo estimado."}
  ],
  "generated_at": "Mês Ano",
  "next_steps": "Próximos passos após os quick wins."
}

REGRAS OBRIGATÓRIAS:
- Retorne APENAS o JSON, nada mais
- color_var deve ser um de: purple, blue, accent, cyan, green, red
- content_pillars[].pct (diagnosis) é número inteiro sem %
- weekly_calendar: 7 entradas (segunda a domingo)
- viral_hooks: exatamente 5 itens
- quick_wins: exatamente 5 itens
- critical_gaps: entre 4 e 6 itens
- bio_versions: 3 versões
- strategy.content_pillars: 5 pilares
- kpis: 3 itens
"""


# ── helpers ───────────────────────────────────────────────────────────────────

def _extract_json(raw: str) -> dict:
    """
    Extrai o primeiro objeto JSON válido de uma string de resposta da IA.
    Lida com:
      - Markdown code fences (```json ... ```)
      - Texto antes/depois do JSON
      - Múltiplos objetos separados por texto extra
    """
    raw = raw.strip()

    # Remove code fences
    if raw.startswith("```"):
        raw = re.sub(r"^```[a-z]*\n?", "", raw)
        raw = re.sub(r"\n?```.*$", "", raw, flags=re.DOTALL)
        raw = raw.strip()

    # Tenta parse direto (caso ideal)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass

    # Encontra o primeiro '{' e usa o decoder para parar no fim do objeto
    start = raw.find("{")
    if start == -1:
        raise RuntimeError(f"Nenhum objeto JSON encontrado na resposta.\nResposta:\n{raw[:500]}")

    decoder = json.JSONDecoder()
    try:
        obj, _ = decoder.raw_decode(raw, start)
        return obj
    except json.JSONDecodeError as e:
        raise RuntimeError(
            f"A IA não retornou JSON válido: {e}\n"
            f"Primeiros 500 chars da resposta:\n{raw[:500]}"
        )


def _read_zip(zip_path: str) -> tuple[str, list[tuple[str, str, str]]]:
    """
    Lê o ZIP e retorna (profile_json_str, [(filename, base64_data, mime_type), ...]).
    Ordem: avatar.jpg primeiro, depois posts em ordem alfabética.
    """
    profile_json = ""
    images: list[tuple[str, str, str]] = []

    with zipfile.ZipFile(zip_path) as zf:
        names = sorted(zf.namelist())
        for name in names:
            basename = os.path.basename(name)
            if basename == "profile.json":
                profile_json = zf.read(name).decode("utf-8")
            elif basename.endswith((".jpg", ".jpeg", ".png", ".webp")):
                raw = zf.read(name)
                b64 = base64.standard_b64encode(raw).decode()
                mime = "image/png" if basename.endswith(".png") else "image/jpeg"
                images.append((basename, b64, mime))

    return profile_json, images


def _build_text_prompt(user_prompt: str, profile_json: str) -> str:
    try:
        data = json.loads(profile_json)
        summary = (
            f"@{data.get('username')} | {data.get('full_name')} | "
            f"Seguidores: {data.get('followers')} | Posts: {data.get('posts_count')} | "
            f"Verificado: {data.get('verified')} | Bio: {data.get('bio')}"
        )
    except Exception:
        summary = profile_json

    return (
        f"{user_prompt}\n\n"
        f"--- Dados do perfil ---\n{summary}\n\n"
        "As imagens a seguir são: avatar do perfil e os primeiros posts (fixados primeiro)."
    )


# ── providers ─────────────────────────────────────────────────────────────────

def _analyze_claude(prompt: str, images: list, model: str, system: str | None = None) -> str:
    import anthropic

    client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

    content: list = []
    for fname, b64, mime in images:
        content.append({
            "type": "image",
            "source": {"type": "base64", "media_type": mime, "data": b64},
        })
    content.append({"type": "text", "text": prompt})

    kwargs: dict = {
        "model": model,
        "max_tokens": 8192,
        "messages": [{"role": "user", "content": content}],
    }
    if system:
        kwargs["system"] = system

    resp = client.messages.create(**kwargs)
    return resp.content[0].text


def _analyze_gemini(prompt: str, images: list, model: str, system: str | None = None) -> str:
    import google.generativeai as genai

    genai.configure(api_key=os.environ["GOOGLE_API_KEY"])

    parts: list = []
    for fname, b64, mime in images:
        parts.append({"inline_data": {"mime_type": mime, "data": b64}})
    # Para Gemini, o system prompt é prefixado ao user prompt
    full = f"{system}\n\n{prompt}" if system else prompt
    parts.append(full)

    m = genai.GenerativeModel(model)
    resp = m.generate_content(parts)
    return resp.text


def _analyze_openai_compat(
    prompt: str,
    images: list,
    model: str,
    api_key: str,
    base_url: str | None = None,
    system: str | None = None,
    json_mode: bool = False,
) -> str:
    from openai import OpenAI

    kwargs: dict = {"api_key": api_key}
    if base_url:
        kwargs["base_url"] = base_url

    client = OpenAI(**kwargs)

    messages: list = []
    if system:
        messages.append({"role": "system", "content": system})

    content: list = [{"type": "text", "text": prompt}]
    for fname, b64, mime in images:
        content.append({
            "type": "image_url",
            "image_url": {"url": f"data:{mime};base64,{b64}"},
        })
    messages.append({"role": "user", "content": content})

    create_kwargs: dict = {
        "model": model,
        "messages": messages,
        "max_tokens": 8192,
    }
    if json_mode:
        create_kwargs["response_format"] = {"type": "json_object"}

    resp = client.chat.completions.create(**create_kwargs)
    return resp.choices[0].message.content


# ── public API ────────────────────────────────────────────────────────────────

DEFAULT_MODELS = {
    "claude": "claude-sonnet-4-6",
    "gemini": "gemini-2.0-flash",
    "openai": "gpt-4o",
    "openrouter": "openai/gpt-4o",
}

# Fallback chain para OpenRouter /free — tentados em ordem
# Nota: modelos :free exigem que a conta tenha crédito adicionado em openrouter.ai/credits
OPENROUTER_FREE_FALLBACKS = [
    "meta-llama/llama-4-scout:free",          # multimodal (visão)
    "meta-llama/llama-4-maverick:free",        # multimodal (visão)
    "qwen/qwen2.5-vl-72b-instruct:free",       # multimodal (visão)
    "google/gemini-2.0-flash-exp:free",        # multimodal (visão)
    "google/gemma-3-27b-it:free",
    "meta-llama/llama-3.3-70b-instruct:free",
    "qwen/qwen3-235b-a22b:free",
    "qwen/qwen3-30b-a3b:free",
    "mistralai/mistral-nemo:free",
    "deepseek/deepseek-chat:free",
]

# Ordem de preferência para Gemini — será filtrada pelos modelos disponíveis na chave
GEMINI_PREFERENCE = [
    "gemini-2.5-pro",
    "gemini-2.5-flash",
    "gemini-2.0-flash",
    "gemini-2.0-flash-lite",
    "gemini-1.5-pro",
    "gemini-1.5-flash",
    "gemini-1.5-flash-8b",
]


def _is_rate_limit(exc: Exception) -> bool:
    msg = str(exc).lower()
    return any(k in msg for k in ("429", "quota", "rate limit", "resource_exhausted",
                                  "too many requests", "ratelimiterror"))


def _is_retryable_gemini(exc: Exception) -> bool:
    """Erros que justificam tentar o próximo modelo."""
    msg = str(exc).lower()
    return _is_rate_limit(exc) or any(k in msg for k in (
        "404", "not found", "not supported", "model not found",
        "permission", "disabled", "unavailable", "overloaded",
    ))


def _get_gemini_models() -> list[str]:
    """
    Consulta a API e retorna modelos disponíveis para a chave,
    ordenados pela preferência em GEMINI_PREFERENCE.
    """
    import google.generativeai as genai
    genai.configure(api_key=os.environ["GOOGLE_API_KEY"])

    try:
        available = {
            m.name.replace("models/", "")
            for m in genai.list_models()
            if "generateContent" in m.supported_generation_methods
        }
    except Exception as e:
        print(f"[ai] Aviso: não foi possível listar modelos Gemini ({e}). Usando lista padrão.")
        return GEMINI_PREFERENCE

    ordered = [m for m in GEMINI_PREFERENCE if m in available]
    extras  = sorted(available - set(GEMINI_PREFERENCE))  # modelos não listados acima

    if ordered:
        print(f"[ai] Modelos Gemini disponíveis para esta chave: {ordered + extras}")
    else:
        print(f"[ai] Nenhum modelo preferido disponível. Disponíveis: {sorted(available)}")
        ordered = extras  # tenta o que tiver

    return ordered or GEMINI_PREFERENCE  # fallback para a lista estática se a API retornar vazio


def _dispatch(
    prompt: str,
    images: list,
    provider: str,
    model: str,
    system: str | None = None,
    json_mode: bool = False,
) -> str:
    """Chama o provider com fallback automático em caso de erro de quota/rate-limit."""

    if provider == "gemini":
        # Consulta quais modelos a chave tem acesso, depois ordena por preferência
        available = _get_gemini_models()
        # Modelo explícito do usuário vai na frente se não estiver na lista
        chain = ([model] if model not in available else []) + available
        last_exc: Exception | None = None
        for m in chain:
            try:
                print(f"[ai] Gemini → {m}")
                return _analyze_gemini(prompt, images, m, system=system)
            except Exception as e:
                if _is_retryable_gemini(e):
                    print(f"[ai] Falhou ({type(e).__name__}: {str(e)[:80]}), tentando próximo...")
                    last_exc = e
                    continue
                raise
        raise RuntimeError(f"Todos os modelos Gemini falharam. Último erro: {last_exc}")

    elif provider == "openrouter":
        # Se o modelo for /free (ou começar com openrouter/free), usa a cadeia de fallback
        is_free = model in ("openrouter/free", "") or model.endswith(":free")
        chain = OPENROUTER_FREE_FALLBACKS if is_free else [model]
        last_exc = None
        for m in chain:
            try:
                print(f"[ai] OpenRouter → {m}")
                return _analyze_openai_compat(
                    prompt, images, m,
                    api_key=os.environ["OPENROUTER_API_KEY"],
                    base_url="https://openrouter.ai/api/v1",
                    system=system,
                )
            except Exception as e:
                msg = str(e).lower()
                if _is_rate_limit(e) or any(k in msg for k in ("404", "not found", "no endpoints", "unavailable", "provider returned error")):
                    print(f"[ai] Falhou ({type(e).__name__}), tentando próximo...")
                    last_exc = e
                    continue
                raise
        raise RuntimeError(f"Todos os modelos OpenRouter falharam. Último erro: {last_exc}")

    elif provider == "claude":
        return _analyze_claude(prompt, images, model, system=system)

    elif provider == "openai":
        return _analyze_openai_compat(
            prompt, images, model,
            api_key=os.environ["OPENAI_API_KEY"],
            system=system,
            json_mode=json_mode,
        )

    else:
        raise ValueError(
            f"AI_PROVIDER inválido: '{provider}'. "
            "Valores aceitos: claude, gemini, openai, openrouter"
        )


# ── JSON schema para relatório comparativo ───────────────────────────────────

COMPARISON_SCHEMA_PROMPT = """\
Você é um especialista em estratégia de Instagram e análise competitiva de mercado.
Você receberá dados completos de múltiplos perfis do Instagram já analisados individualmente.
Sua tarefa é gerar uma análise comparativa profunda entre todos eles.
Retorne APENAS um JSON válido, sem markdown, sem ```json, sem texto adicional.

O JSON deve seguir EXATAMENTE este schema:

{
  "title": "Análise Comparativa — Benchmarking de Concorrentes",
  "subtitle": "texto descritivo do mercado/nicho analisado",
  "generated_at": "Mês Ano",
  "profiles_analyzed": ["username1", "username2"],
  "market_overview": "Visão geral do mercado/nicho em 3-4 parágrafos: quem são esses players, como se posicionam coletivamente, qual o nível de maturidade do mercado, quais as tendências.",
  "benchmark": [
    {
      "username": "nomeusuario",
      "full_name": "Nome Completo",
      "followers": "ex: 13.5K",
      "posts": "ex: 85",
      "engagement_est": "ex: ~0.6%",
      "score_overall": 82,
      "score_conteudo": 80,
      "score_visual": 75,
      "score_estrategia": 85,
      "score_engajamento": 78,
      "positioning_summary": "Uma frase resumindo o posicionamento deste perfil no mercado.",
      "top_strength": "Principal ponto forte em relação aos concorrentes.",
      "top_weakness": "Principal ponto fraco em relação aos concorrentes.",
      "rank": 1
    }
  ],
  "category_winners": [
    {"category": "Melhor Bio", "winner": "nomeusuario", "why": "Motivo objetivo em 1-2 frases."},
    {"category": "Melhor Estratégia de Conteúdo", "winner": "nomeusuario", "why": "..."},
    {"category": "Melhor Consistência de Publicação", "winner": "nomeusuario", "why": "..."},
    {"category": "Melhor Identidade Visual", "winner": "nomeusuario", "why": "..."},
    {"category": "Maior Potencial de Crescimento", "winner": "nomeusuario", "why": "..."},
    {"category": "Mais Orientado a Conversão", "winner": "nomeusuario", "why": "..."}
  ],
  "market_gaps": [
    {
      "gap": "Desafio ou lacuna identificada no mercado.",
      "opportunity": "Como explorar essa lacuna.",
      "who_benefits": "nomeusuario ou 'todos os perfis'"
    }
  ],
  "profile_deep_dives": [
    {
      "username": "nomeusuario",
      "what_works": ["Ponto forte 1", "Ponto forte 2", "Ponto forte 3"],
      "what_doesnt": ["Ponto fraco 1", "Ponto fraco 2"],
      "steal_this": "O que os outros concorrentes podem aprender ou adaptar deste perfil.",
      "avoid_this": "Erro ou fraqueza que os outros devem evitar."
    }
  ],
  "final_recommendations": [
    {
      "for": "nomeusuario",
      "priority": "Alta",
      "action": "Ação específica recomendada.",
      "rationale": "Por que esta ação é prioritária para este perfil agora."
    }
  ],
  "executive_summary": "Resumo executivo em 3-4 parágrafos: ranking final com justificativa, quem está melhor posicionado e por quê, as maiores oportunidades de mercado, e os principais takeaways para qualquer player neste nicho."
}

REGRAS OBRIGATÓRIAS:
- Retorne APENAS o JSON, nada mais
- benchmark: inclua TODOS os perfis fornecidos, ordenados do melhor (rank 1) para o pior
- scores: números inteiros de 0 a 100
- category_winners: exatamente 6 categorias
- market_gaps: entre 3 e 5 gaps
- profile_deep_dives: inclua TODOS os perfis
- final_recommendations: pelo menos 1 recomendação por perfil, prioridade = Alta|Média|Baixa
- winner em category_winners deve ser o username sem @
"""


def _build_comparison_prompt(
    profiles_report_data: dict,   # username -> dict com dados do relatório individual
    profiles_stats: dict,         # username -> dict do profile.json
) -> str:
    """Monta o texto que será enviado para a IA de comparação."""
    sections = []
    for username, data in profiles_report_data.items():
        stats = profiles_stats.get(username, {})
        h = data.get("header", {})
        d = data.get("diagnosis", {})
        s = data.get("strategy", {})
        icp = data.get("icp", {})

        pillars = ", ".join(
            f"{p.get('name')} ({p.get('pct')}%)"
            for p in s.get("content_pillars", [])
        )
        gaps = " | ".join(g.get("title", "") for g in d.get("critical_gaps", []))

        section = f"""=== @{username} ===
Nome: {h.get('full_name', stats.get('full_name', ''))}
Seguidores: {h.get('stats', {}).get('followers', stats.get('followers', '?'))}
Posts: {h.get('stats', {}).get('posts', stats.get('posts_count', '?'))}
Engagement Estimado: {h.get('stats', {}).get('engagement_rate', '?')}

--- DIAGNÓSTICO ---
Posicionamento Atual: {d.get('current_positioning', '')}
Veredicto: {d.get('positioning_verdict', '')}
Problema Central: {d.get('central_problem', '')}
Tom de Voz: {d.get('tone', '')}
Identidade Visual: {d.get('visual', '')}
Público Atual: {d.get('audience_current', '')}
Público Ideal: {d.get('audience_target', '')}
Gap de Público: {d.get('audience_gap', '')}
Gaps Críticos: {gaps}

--- ESTRATÉGIA ---
Novo Posicionamento: {s.get('new_positioning', '')}
Pilares de Conteúdo: {pillars}
Funil Topo: {s.get('funnel_top', '')}
Funil Fundo: {s.get('funnel_bottom', '')}

--- ICP ---
Perfil Primário: {icp.get('primary_title', '')} — {icp.get('primary_demographics', '')}
Dores: {' | '.join(icp.get('pains', [])[:3])}
"""
        sections.append(section.strip())

    return (
        "Abaixo estão os dados completos de cada perfil analisado individualmente.\n"
        "Gere a análise comparativa conforme o schema.\n\n"
        + "\n\n".join(sections)
    )


def analyze_zip(zip_path: str, prompt: str) -> str:
    """Retorna texto livre de análise."""
    provider = os.getenv("AI_PROVIDER", "claude").lower()
    model = os.getenv("AI_MODEL", "") or DEFAULT_MODELS.get(provider, "")
    profile_json, images = _read_zip(zip_path)
    full_prompt = _build_text_prompt(prompt, profile_json)
    print(f"[ai] Provider: {provider} | Modelo inicial: {model} | Imagens: {len(images)}")
    return _dispatch(full_prompt, images, provider, model)


def analyze_comparison_json(
    zip_paths: dict,          # username -> zip_path
    reports_data: dict,       # username -> report dict (já analisado individualmente)
) -> dict:
    """
    Gera análise comparativa entre múltiplos perfis.
    Usa apenas dados de texto (sem imagens) para o relatório comparativo.
    Retorna dict pronto para render_comparison_html().
    """
    provider = os.getenv("AI_PROVIDER", "claude").lower()
    model = os.getenv("AI_MODEL", "") or DEFAULT_MODELS.get(provider, "")

    # Lê profile.json de cada ZIP para ter stats brutos
    profiles_stats: dict = {}
    for username, zip_path in zip_paths.items():
        try:
            pjson, _ = _read_zip(zip_path)
            profiles_stats[username] = json.loads(pjson) if pjson else {}
        except Exception:
            profiles_stats[username] = {}

    comparison_prompt = _build_comparison_prompt(reports_data, profiles_stats)

    print(f"[ai] Comparativo | Provider: {provider} | Modelo: {model} | Perfis: {list(zip_paths.keys())}")

    json_mode = provider == "openai"
    raw = _dispatch(
        comparison_prompt,
        [],           # sem imagens no comparativo
        provider,
        model,
        system=COMPARISON_SCHEMA_PROMPT,
        json_mode=json_mode,
    )

    return _extract_json(raw)


def analyze_zip_json(zip_path: str, prompt: str) -> dict:
    """
    Envia para a IA com o schema de relatório estruturado.
    Retorna um dict pronto para render_html().
    """
    provider = os.getenv("AI_PROVIDER", "claude").lower()
    model = os.getenv("AI_MODEL", "") or DEFAULT_MODELS.get(provider, "")
    profile_json, images = _read_zip(zip_path)
    full_prompt = _build_text_prompt(prompt, profile_json)
    print(f"[ai] JSON report | Provider: {provider} | Modelo inicial: {model} | Imagens: {len(images)}")

    json_mode = provider == "openai"
    raw = _dispatch(full_prompt, images, provider, model,
                    system=REPORT_SCHEMA_PROMPT, json_mode=json_mode)

    return _extract_json(raw)
